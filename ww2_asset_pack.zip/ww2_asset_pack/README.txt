WW2 Asset Pack
License: CC0 1.0 — see LICENSE.txt.
Includes 1024px tileable ground/wall/wood textures, original sky, transparent smoke/dust sprites, UI, and low-poly GLB starter models.
Models generated: True
Audio is not included in this first pack.
